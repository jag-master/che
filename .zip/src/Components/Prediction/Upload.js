import React from "react";
import axios from "axios";
import ResultUI from "./Result";

export default function Alzehimer() {
  const [capturedImage, setCapturedImage] = React.useState(null);
  const [result, setResult] = React.useState(-1);
  const [loading, setLoading] = React.useState(false);

  const CameraCapture2 = async (event) => {
    setLoading(true);
    setResult(-1);
    setCapturedImage(null);

    setTimeout(() => {
      setLoading(false);
      window.scrollTo({
        top: window.pageYOffset + 800,
        behavior: "smooth",
      });
    }, 1000);

    const fileInput = event.target.files[0];

    setCapturedImage(URL.createObjectURL(fileInput));
    const formData = new FormData();
    formData.append("image", fileInput, "image.png");

    try {
      const response = await axios.post(
        "http://localhost:5000/upload",
        formData
      );
      console.log(response.data);
      setResult(response.data.predicted_class);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="bg-white" style={{ backgroundColor: "white" }}>
      <div className="mx-auto w-full">
        <div className="relative isolate overflow-hidden bg-gray-900 px-6 pt-16 shadow-2xl  sm:px-16 md:pt-24 lg:flex lg:gap-x-20 lg:px-24 lg:pt-0">
          <svg
            viewBox="0 0 1024 1024"
            className="absolute left-1/2 top-1/2 -z-10 h-[64rem] w-[64rem] -translate-y-1/2 [mask-image:radial-gradient(closest-side,white,transparent)] sm:left-full sm:-ml-80 lg:left-1/2 lg:ml-0 lg:-translate-x-1/2 lg:translate-y-0"
            aria-hidden="true"
          >
            <circle
              cx={512}
              cy={512}
              r={512}
              fill="url(#759c1415-0410-454c-8f7c-9a820de03641)"
              fillOpacity="0.7"
            />
            <defs>
              <radialGradient id="759c1415-0410-454c-8f7c-9a820de03641">
                <stop stopColor="#7775D6" />
                <stop offset={1} stopColor="#E935C1" />
              </radialGradient>
            </defs>
          </svg>
          <div className="mx-auto max-w-md text-center lg:mx-0 lg:flex-auto lg:py-32 lg:text-left">
            <h1
              className=""
              style={{
                fontSize: "60px",
                color: "white",
                fontWeight: 900,
                lineHeight: "60px",
              }}
            >
              Alzheimer’s Disease Detection
            </h1>
            <p className="mt-6 text-lg leading-8 text-gray-300">
              Neurodegenerative disorder characterized by the progressive
              decline in cognitive function, memory loss, and changes in
              behavior
            </p>
            <div className="mt-10 flex items-center justify-center gap-x-6 lg:justify-start">
              <input
                type="file"
                id="file-upload"
                style={{ display: "none" }}
                onChange={CameraCapture2}
              />
              <label
                htmlFor="file-upload"
                className="rounded-md bg-white px-3.5 py-2.5 text-sm font-semibold text-gray-900 shadow-sm hover:bg-gray-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
              >
                {loading ? "Predicting..." : "Upload Image"}
              </label>

              <a
                href="#"
                className="text-sm font-semibold leading-6 text-white"
              >
                Learn more <span aria-hidden="true">→</span>
              </a>
            </div>
            <br /> <br /> <br /> <br /> <br />
            <br /> <br /> <br /> <br /> <br />
          </div>
          <div className="relative mt-16  lg:mt-8">
            <img
              className="absolute left-0 top-0 w-[57rem] max-w-none rounded-md bg-white/5 "
              src="https://media0.giphy.com/media/MXQWjQrFToAWtLbGHm/giphy.gif?cid=6c09b952b42d24494b67b9278c23a76f79d48dcecca23ae5&ep=v1_internal_gifs_gifId&rid=giphy.gif&ct=s"
              alt="App screenshot"
              style={{
                height: "570px",
                width: "auto",
                backgroundColor: "inherit",
                border: "none",
              }}
            />
          </div>
        </div>
        {capturedImage && result != -1 ? (
          <div className="relative isolate overflow-hidden bg-gray-900 px-6 pt-16 shadow-2xl  sm:px-16 md:pt-0 lg:flex lg:gap-x-20 lg:px-24 lg:pt-0">
            <ResultUI capturedImage={capturedImage} result={result} />
          </div>
        ) : null}
        {capturedImage && result != -1 ? (
          <div
            style={{
              backgroundColor: "#111827",
              width: "100%",
              height: "50px",
            }}
          ></div>
        ) : null}
      </div>
    </div>
  );
}
